const SOIL_STATES = {
    UNTILLED: 0,
    TILLED: 1,
    WATERED: 2,
    PLANTED: 3,
    GROWN: 4
};

const TILE_BY_STATE = {
    [SOIL_STATES.UNTILLED]: 27,  // row 0, col 0
    [SOIL_STATES.TILLED]: 25,    // row 0, col 4
    [SOIL_STATES.WATERED]: 26,   // row 0, col 5
    [SOIL_STATES.PLANTED]: 26,   // row 1, col 0
    [SOIL_STATES.GROWN]: 28      // row 1, col 1
};

class GameScene extends Phaser.Scene {
    constructor() {
        super('GameScene')
        this.soilStateMap = []; // <-- store tile states here
    }

    preload() {
        this.cursors
        this.cameras.main.setBackgroundColor(0x000000)
        this.load.image('tiles', '../assets/Tilemap/tileTest.png')
        this.load.tilemapTiledJSON('map', '../assets/Tilemap/ground.json')

        this.load.spritesheet('characters', '../assets/characters.png', {
            frameWidth: 16,
            frameHeight: 32
        })

        this.player
        this.keys

    } //end preload

    create() {

        const map = this.make.tilemap({ key: 'map'})
        const tileset = map.addTilesetImage('ground', 'tiles'); // tileset name, image key

        // static layers that do not change
        this.worldLayer = map.createStaticLayer('background', tileset, 0, 0);

        // dynamic layers do change
        this.soilLayer = map.createDynamicLayer('soil', tileset, 0, 0);

        //initialize soil tile data 
        this.soilLayer.layer.data.forEach((row, y) => {
            this.soilStateMap[y] = [];
            row.forEach((tile, x) => {
                this.soilStateMap[y][x] = tile && tile.index !== -1 ? SOIL_STATES.UNTILLED : null;
            });
        });

        // Initialize soil state array
        this.soilStateMap = [];
        this.soilLayer.layer.data.forEach((row, y) => {
            this.soilStateMap[y] = [];
            row.forEach((tile, x) => {
                this.soilStateMap[y][x] = tile && tile.index !== -1 ? SOIL_STATES.UNTILLED : null;
            });
        });


        // world physics
        this.physics.world.bounds.width = map.widthInPixels
        this.physics.world.bounds.height = map.heightInPixels
        this.cameras.main.setBounds(0, 0, map.widthInPixels, map.heightInPixels)

        const debugGraphics = this.add.graphics().setAlpha(0.2)
        this.worldLayer.renderDebug(debugGraphics, {
            tileColor: null,
            collidingTileColor: new Phaser.Display.Color(0, 0, 255),
            faceColor: new Phaser.Display.Color(0, 255, 0, 255)
        })

        //player
        this.player = new Player (this, 50, 50, 'characters')
        this.physics.add.collider(this.player, this.worldLayer)
        this.cameras.main.startFollow(this.player, true, 0.5, 0.5)
        this.player.body.setCollideWorldBounds(true)

        //imput handler
        this.input.on('pointerdown', this.handleClick, this);
    } //end create

    handleClick(pointer) {
        const worldPoint = pointer.positionToCamera(this.cameras.main);

        const tile = this.soilLayer.getTileAtWorldXY(worldPoint.x, worldPoint.y);
        if (tile) this.handleSoilInteraction(tile);
    }

    handleSoilInteraction(tile) {
        const currentState = this.soilStateMap[tile.y][tile.x];

        // Cycle to next state
        const nextState = (currentState + 1) % 5;
        this.soilStateMap[tile.y][tile.x] = nextState;

        // Update the tile visually on the map
        const newTileIndex = TILE_BY_STATE[nextState];
        this.soilLayer.putTileAt(newTileIndex, tile.x, tile.y);
    }
    

    update(time, delta) {
        this.player.update()

    } //end update



}    //end gameScene